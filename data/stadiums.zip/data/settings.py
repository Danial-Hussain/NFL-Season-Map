BOT_NAME = 'data'

SPIDER_MODULES = ['data.spiders']
NEWSPIDER_MODULE = 'data.spiders'

USER_AGENT = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'

ROBOTSTXT_OBEY = True