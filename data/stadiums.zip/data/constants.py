# URLS
NFL_TEAMS_URL = "http://www.espn.com/nfl/schedulegrid/_/year/"

# CSS Selectors
NFL_TEAMS_CSS_SELECTOR = "b a::text"
NFL_SCHEDULE_CSS_SELECTOR = "tr td"
